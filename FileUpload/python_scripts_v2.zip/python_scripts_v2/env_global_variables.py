# env_global_variables.py

glb_wait_secs = 5
glb_max_concur_jobs = 30
glb_gcs_rw_scope = 'https://www.googleapis.com/auth/devstorage.read_write'
glb_gcs_ro_scope = 'https://www.googleapis.com/auth/devstorage.read_only'
glb_bq_scope = 'https://www.googleapis.com/auth/bigquery'
glb_client_secret = '/var/opt/talend-job-executions/job-exec/dynamic_data_ingestion/python_scripts_v2/etl-shared-service-account@tccc-dev-shared-services.iam.gserviceaccount.com.json'
#glb_client_secret = 'C:\gcp-sl-pilot\secrets\etl-shared-service-account@tccc-dev-shared-services-0001.iam.gserviceaccount.com.json'
